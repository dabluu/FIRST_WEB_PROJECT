package com.mphasis.hrms.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.hrms.entity.AccountId;
import com.mphasis.hrms.entity.Order;
import com.mphasis.hrms.repository.OrderRepository;



@Component("os")
public class OrderService {
    @Autowired
    private OrderRepository orderRepo;
    
    public Order create(Order order) 
    {
        return orderRepo.save(order);
    }
    public List<Order> read() 
    {
        return orderRepo.findAll();
    }
    public Order read(Integer orderId) 
    {
        return orderRepo.findById(orderId).get();
    }
    public Order update(Order order) 
    {
        return orderRepo.save(order);
    }
    public void delete(Integer orderId) 
    {
        orderRepo.delete(read(orderId));
    }
    
    public int updateStatus(String status,Integer orderId,String bookId) {
    	return orderRepo.updateStatus(status,orderId,bookId);
    }

    
}