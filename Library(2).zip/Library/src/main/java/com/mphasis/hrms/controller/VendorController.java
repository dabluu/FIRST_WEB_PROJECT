package com.mphasis.hrms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.mphasis.hrms.entity.Vendor;
import com.mphasis.hrms.service.VendorService;

@RestController
@CrossOrigin(origins= {"http://localhost:4200","*"})
@RequestMapping("/vendor")
public class VendorController {

	@Autowired
	private VendorService vs;


	@GetMapping("/")
    public List<Vendor> getAllBooks()
    {
        //display all branches
        List<Vendor> books = vs.read();
        return books;
    }
    
    @GetMapping("/{vendorId}")            //?bid=B00017 means @RequestParam        but /{bid} means @PathVariable
    public Vendor findVendorById(@PathVariable("vendorId") String vendorId)
    {
        return vs.read(vendorId);
    }
    
    @PostMapping("/")
    public Vendor addBook(@RequestBody Vendor vendor)
    {
        return vs.create(vendor);
    }
    
    @PutMapping("/")
    public Vendor modifyVendor(@RequestBody Vendor vendor)
    {
        return vs.update(vendor);
    }
    
    @DeleteMapping("/{vendorId}")
    public void deleteBook(@PathVariable("vendorId") String vendorId)
    {
        vs.delete(vendorId);
    }
}
