package com.mphasis.hrms.controller;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.hrms.entity.User;
import com.mphasis.hrms.service.UserService;

@RestController
@CrossOrigin(origins= {"http://localhost:4200","*"})
@RequestMapping("/user")
public class UserController {
	@Autowired
	UserService us;
	
	@GetMapping("/")
	public List<User> getAllUsers() {
		List<User> users = us.read();
		return users;
	}
	
	@GetMapping("/{userId}/{password}")
	public User validateLogin(@PathVariable("userId") String userId,@PathVariable("password") String password) throws NoSuchAlgorithmException {
		String password1= encryptSha1(password);
		return us.validateLogin(userId, password1);
	}
	
	@PostMapping("otp")
    public String generateOtp(@RequestBody String email)
    {
        double x=Math.random()*1000000;
        int otp=(int)x;
        System.out.println("Sending email to : "+email);
        sendEmail(email, "The OTP required for signing up to the application is "+otp+" Do not share the otp with anybody /n http://localhost:4200/(col3:signup)");
        return ""+otp;
    }
	
	private void sendEmail(String to, String message)
	{
		 Properties props = new Properties();
	        props.put("mail.smtp.host", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "587");
	        props.put("mail.smtp.auth", "true");
	        //Establishing a session with required user details
	        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
	            protected PasswordAuthentication getPasswordAuthentication() {
	                return new PasswordAuthentication("mns.reddy300@gmail.com", "mns@301998");
	            }
	        });
	        try {
	            //Creating a Message object to set the email content
	            MimeMessage msg = new MimeMessage(session);
	            //Storing the comma seperated values to email addresses
//	            String to = "rjagadeeswaran@yahoo.com";
	            /*Parsing the String with defualt delimiter as a comma by marking the boolean as true and storing the email
	            addresses in an array of InternetAddress objects*/
	            InternetAddress[] address = InternetAddress.parse(to, true);
	            //Setting the recepients from the address variable
	            msg.setRecipients(Message.RecipientType.TO, address);
	            String timeStamp = new SimpleDateFormat("yyyymmdd_hh-mm-ss").format(new Date());
	            msg.setSubject("Otp : " + timeStamp);
	            msg.setSentDate(new Date());
	            msg.setText(message);
	            msg.setHeader("XPriority", "1");
	           
	            Transport.send(msg);
	            System.out.println("Mail has been sent successfully");
	        } catch (MessagingException mex) {
	            System.out.println("Unable to send an email:\n" + mex);
	        }
	}
	
	@GetMapping("/{userId}")         
	public User finduserById(@PathVariable("userId") String userId)
	{
		return us.read(userId);
	}
	
//	@PostMapping("/")
//	public User addUser(@RequestBody User user) {
//		return us.create(user);
//	}
	
	public String encryptSha1(String password) throws NoSuchAlgorithmException
	{
	    //String password = "123456";
	        MessageDigest md = MessageDigest.getInstance("SHA-256");
	        byte[] hashInBytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
	        // bytes to hex
	        StringBuilder sb = new StringBuilder();
	        for (byte b : hashInBytes) {
	            sb.append(String.format("%02x", b));
	        }
	        //System.out.println(sb.toString());
	    return sb.toString();
	}
	
	@PostMapping("/")
	public User addUser(@RequestParam("userId")String userId,@RequestParam("firstName")String firstName,@RequestParam("lastName")String lastName,@RequestParam("password")String password,@RequestParam("dateOfBirth")String dateOfBirth,@RequestParam("email")String email,@RequestParam("contactNo")String contactNo,@RequestParam("role")String role) throws ParseException, NoSuchAlgorithmException {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    	Date dob=sdf.parse(dateOfBirth);
    	
    	String password1= encryptSha1(password);
    	User user=new User(userId,firstName,lastName,password1,dob,email,contactNo,role);
		return us.create(user);
	}
	
	
	@PutMapping("/")
	public User modifyUser(@RequestBody User user) {
		return us.update(user);
	}
	
	@DeleteMapping("/{userId}")
	public void deleteUser(@PathVariable("userId") String userId) {
		us.delete(userId);
	}

}
