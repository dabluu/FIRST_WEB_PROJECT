package com.mphasis.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.hrms.entity.Book;
import com.mphasis.hrms.repository.BookRepository;



@Component("bs")
public class BookService {
    @Autowired
    private BookRepository bookRepo;
    
    public Book create(Book book) 
    {
        return bookRepo.save(book);
    }
    public List<Book> read() 
    {
        return bookRepo.findAll();
    }
    public Book read(String bookId) 
    {
        return bookRepo.findById(bookId).get();
    }
    public Book update(Book book) 
    {
        return bookRepo.save(book);
    }
    public void delete(String bookId) 
    {
        bookRepo.delete(read(bookId));
    }
    
}