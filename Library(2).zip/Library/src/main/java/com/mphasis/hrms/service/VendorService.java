package com.mphasis.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.mphasis.hrms.entity.Vendor;
import com.mphasis.hrms.repository.VendorRepository;

@Component("vs")
public class VendorService {

	 @Autowired
	    private VendorRepository VendorRepo;
	    
	    public Vendor create(Vendor vendor) 
	    {
	        return VendorRepo.save(vendor);
	    }
	    public List<Vendor> read() 
	    {
	        return VendorRepo.findAll();
	    }
	    public Vendor read(String bookId) 
	    {
	        return VendorRepo.findById(bookId).get();
	    }
	    public Vendor update(Vendor vendor) 
	    {
	        return VendorRepo.save(vendor);
	    }
	    public void delete(String vendorId) 
	    {
	        VendorRepo.delete(read(vendorId));
	    }
	    
}
