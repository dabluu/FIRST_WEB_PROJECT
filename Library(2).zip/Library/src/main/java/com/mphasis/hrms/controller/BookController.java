package com.mphasis.hrms.controller;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mphasis.hrms.entity.Book;
import com.mphasis.hrms.service.BookService;
@RestController
@CrossOrigin(origins= {"http://localhost:4200","*"})
@RequestMapping("/book")
@MultipartConfig
public class BookController {
	@Autowired
	private BookService bs;
//	BookService bs = new BookService(); 

	@GetMapping("/")
    public List<Book> getAllBooks()
    {
        //display all branches
        List<Book> books = bs.read();
        return books;
    }
    
    @GetMapping("/{bookId}")            //?bid=B00017 means @RequestParam        but /{bid} means @PathVariable
    public Book findBookById(@PathVariable("bookId") String bookId)
    {
        return bs.read(bookId);
    }
    //@PostMapping("/")
    //public Book addBook(@RequestBody Book book)
    //{
    //    return bs.create(book);
    //}
    
    @PostMapping("/")
    public Book addBook(@RequestParam("bookId")String bookId,@RequestParam("title")String title,@RequestParam("authorName")String authorName,@RequestParam("version")String version,@RequestParam("publishDate")String publishDate,@RequestParam("dept")String dept,@RequestParam("language")String language,@RequestParam("cost")Integer cost,@RequestParam("pages")Integer pages,@RequestParam("description")String description,@RequestParam("photo")MultipartFile file) throws ParseException, IOException {
    	
    	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    	Date dob=sdf.parse(publishDate);
    	
    	byte []photo=file.getBytes();
    	//FileOutputStream fos=new FileOutputStream(file.getName());
    	//fos.write(photo);            //you can find this photo above pom.xml in springtool
    	//fos.flush();
    	//fos.close();
    	
    	Book book=new Book(bookId,title,authorName,version,dob,dept,language,cost,pages,description,photo, null, null);
    	return bs.create(book);
    }
    
    
    @PutMapping("/")
    public Book modifyBook(@RequestParam("bookId")String bookId,@RequestParam("title")String title,@RequestParam("authorName")String authorName,@RequestParam("version")String version,@RequestParam("publishDate")String publishDate,@RequestParam("dept")String dept,@RequestParam("language")String language,@RequestParam("cost")Integer cost,@RequestParam("pages")Integer pages,@RequestParam("description")String description,@RequestParam("photo")MultipartFile file) throws ParseException, IOException {
    	
    	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    	Date dob=sdf.parse(publishDate);
    	
    	byte []photo=file.getBytes();
    	//FileOutputStream fos=new FileOutputStream(file.getName());
    	//fos.write(photo);            //you can find this photo above pom.xml in springtool
    	//fos.flush();
    	//fos.close();
    	
    	Book book=new Book(bookId,title,authorName,version,dob,dept,language,cost,pages,description,photo, null, null);
    	return bs.update(book);
    }
    
    //@PutMapping("/")
    //public Book modifyBook(@RequestBody Book book)
    //{
    //    return bs.update(book);
    //}
    
    @DeleteMapping("/{bookId}")
    public void deleteBook(@PathVariable("bookId") String bookId)
    {
        bs.delete(bookId);
    }
}

    
    