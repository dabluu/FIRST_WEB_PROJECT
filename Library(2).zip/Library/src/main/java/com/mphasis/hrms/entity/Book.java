package com.mphasis.hrms.entity;

import java.text.ParseException;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name="book")
public class Book {
  @Id
  private String bookId;
  private String title;
  private String authorName;
  private String version;
  private Date publishDate;
  private String dept;
  private String language;
  private Integer cost;
  private Integer pages;
  private String description;
  @Lob
  private byte[] photo;
  @OneToMany(mappedBy="book")
  private List<Junction> junctionList;
  @OneToMany(mappedBy="book")
  private List<Order> orderList;
  
  public Book() {
  }

public Book(String bookId, String title, String authorName, String version, Date publishDate, String dept,
		String language, Integer cost, Integer pages, String description, byte[] photo, List<Junction> junctionList,
		List<Order> orderList) {
	super();
	this.bookId = bookId;
	this.title = title;
	this.authorName = authorName;
	this.version = version;
	this.publishDate = publishDate;
	this.dept = dept;
	this.language = language;
	this.cost = cost;
	this.pages = pages;
	this.description = description;
	this.photo = photo;
	this.junctionList = junctionList;
	this.orderList = orderList;
}

public Book(String bookId, String title, String authorName, String version, Date publishDate, String dept,
		String language, Integer cost, Integer pages, String description, byte[] photo) {
	super();
	this.bookId = bookId;
	this.title = title;
	this.authorName = authorName;
	this.version = version;
	this.publishDate = publishDate;
	this.dept = dept;
	this.language = language;
	this.cost = cost;
	this.pages = pages;
	this.description = description;
	this.photo = photo;
}

public String getBookId() {
	return bookId;
}

public void setBookId(String bookId) {
	this.bookId = bookId;
}

public String getTitle() {
	return title;
}

public void setTitle(String title) {
	this.title = title;
}

public String getAuthorName() {
	return authorName;
}

public void setAuthorName(String authorName) {
	this.authorName = authorName;
}

public String getVersion() {
	return version;
}

public void setVersion(String version) {
	this.version = version;
}

public Date getPublishDate() {
	return publishDate;
}

public void setPublishDate(Date publishDate) {
	this.publishDate = publishDate;
}

public String getDept() {
	return dept;
}

public void setDept(String dept) {
	this.dept = dept;
}

public String getLanguage() {
	return language;
}

public void setLanguage(String language) {
	this.language = language;
}

public Integer getCost() {
	return cost;
}

public void setCost(Integer cost) {
	this.cost = cost;
}

public Integer getPages() {
	return pages;
}

public void setPages(Integer pages) {
	this.pages = pages;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public byte[] getPhoto() {
	return photo;
}

public void setPhoto(byte[] photo) {
	this.photo = photo;
}


  
  
  
}
