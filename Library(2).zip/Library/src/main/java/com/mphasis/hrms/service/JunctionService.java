package com.mphasis.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.hrms.entity.Junction;
import com.mphasis.hrms.repository.JunctionRepository;


@Component("js")
public class JunctionService {
    @Autowired
    private JunctionRepository junctionRepo;
    
    public Junction create(Junction junction) 
    {
        return junctionRepo.save(junction);
    }
    public List<Junction> read() 
    {
        return junctionRepo.findAll();
    }
    public Junction read(String junctionId) 
    {
        return junctionRepo.findById(junctionId).get();
    }
    public Junction update(Junction junction) 
    {
        return junctionRepo.save(junction);
    }
    public void delete(String junctionId) 
    {
        junctionRepo.delete(read(junctionId));
    }
   

}
