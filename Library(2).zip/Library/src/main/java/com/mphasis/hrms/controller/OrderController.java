package com.mphasis.hrms.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mphasis.hrms.entity.AccountId;
import com.mphasis.hrms.entity.Book;
import com.mphasis.hrms.entity.Order;
import com.mphasis.hrms.entity.User;
import com.mphasis.hrms.service.BookService;
import com.mphasis.hrms.service.OrderService;
import com.mphasis.hrms.service.UserService;
@RestController
@CrossOrigin(origins= {"http://localhost:4200","*"})
@RequestMapping("/order")
public class OrderController {
	@Autowired
	private OrderService os;
	
	@Autowired
	private BookService bs;

	@Autowired
	private UserService us;
//	OrderService os = new OrderService(); 

	@GetMapping("/")
    public List<Order> getAllOrders()
    {
        //display all branches
        List<Order> orders = os.read();
        return orders;
    }
    
    @GetMapping("/{orderId}")            //?bid=B00017 means @RequestParam        but /{bid} means @PathVariable
    public Order findOrderById(@PathVariable("orderId") Integer orderId)
    {
        return os.read(orderId);
    }
    @PostMapping("/")
    public Order addOrder(@RequestParam("bookId")String bookId,@RequestParam("userId")String userId,@RequestParam("status")String status,@RequestParam("orderDate")String orderDate,@RequestParam("address")String address) throws ParseException
    {
    	SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
    	Date dob=sdf.parse(orderDate);
    	System.out.println("started");
    	
    	User user=us.read(userId);
    	System.out.println("user..."+user);
    	
    	Book book=new Book();
    	//find Book by bookId
    	book=bs.read(bookId);
    	System.out.println("book..."+book);
    	
    	    	
    	Order order=new Order(user,book,status,dob,address);
    	System.out.println("Order"+order);
        return os.create(order);
    }
    
    @PutMapping("/")
    public Order modifyOrder(@RequestBody Order order)
    {
        return os.update(order);
    }
    
    @DeleteMapping("/{orderId}")
    public void deleteOrder(@PathVariable("orderId") Integer orderId)
    {
        os.delete(orderId);
    }
    
    @PostMapping("/us")
    public int updateStatus(@RequestParam("status") String status,@RequestParam("orderId") Integer orderId,@RequestParam("bookId") String bookId) {
    	return os.updateStatus(status,orderId,bookId);
    }
}

    
    