package com.mphasis.hrms.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="orders")
//@IdClass(AccountId.class)
public class Order implements Serializable {
	//orderId, userId, bookId, status
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Integer orderId;
    @ManyToOne(targetEntity=User.class)
    private User user;
    @ManyToOne(targetEntity=Book.class)
    private Book book;
    private String status;
    private Date orderDate;
    private String address;
    
    public Order() {}

	public Order(Integer orderId, User user, Book book, String status, Date orderDate, String address) {
		super();
		this.orderId = orderId;
		this.user = user;
		this.book = book;
		this.status = status;
		this.orderDate = orderDate;
		this.address = address;
	}
	
	

	public Order(User user, Book book, String status, Date orderDate, String address) {
		super();
		this.user = user;
		this.book = book;
		this.status = status;
		this.orderDate = orderDate;
		this.address = address;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	
	
    
}
