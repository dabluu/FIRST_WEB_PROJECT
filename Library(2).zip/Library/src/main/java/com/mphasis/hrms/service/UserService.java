package com.mphasis.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.hrms.entity.User;
import com.mphasis.hrms.repository.UserRepository;

@Component("us")
public class UserService {
	@Autowired
	private UserRepository userRepo;
	
	public User create(User user) {
		return userRepo.save(user);
	}
	public List<User> read() {
		return userRepo.findAll();
	}
	public User read(String userId) {
		return userRepo.findById(userId).get();
	}
	public User update(User user) {
		return userRepo.save(user);
	}
	public void delete(String userId) {
		userRepo.delete(read(userId));
	}
	
	
	
	public User validateLogin(String userId,String password) {
		return userRepo.validateLogin(userId,password);
	}
}
