package com.mphasis.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Feedback")
public class Feedback {
	@Id
	
    private String userId;
    private String Experience;
    private String Comments;
    public Feedback() {}
    
    
    
    
    public Feedback(String userId, String experience, String comments) {
		super();
		this.userId = userId;
		Experience = experience;
		Comments = comments;
	}




	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getExperience() {
		return Experience;
	}
	public void setExperience(String experience) {
		Experience = experience;
	}
	public String getComments() {
		return Comments;
	}
	public void setComments(String comments) {
		Comments = comments;
	}




	@Override
	public String toString() {
		return "Feedback [userId=" + userId + ", Experience=" + Experience + ", Comments=" + Comments + "]";
	}
	
	
    
}
