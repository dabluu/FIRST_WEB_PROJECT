package com.mphasis.hrms.entity;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="junction")
public class Junction {
	@Id
    private String junctionId;
	@ManyToOne(targetEntity=Vendor.class)
	private Vendor vendor;
	@ManyToOne(targetEntity=Book.class)
	private Book book;
    private String bookCount;
    
    public Junction() {}

	public Junction(String junctionId, Vendor vendor, Book book, String bookCount) {
		super();
		this.junctionId = junctionId;
		this.vendor = vendor;
		this.book = book;
		this.bookCount = bookCount;
	}

	public String getJunctionId() {
		return junctionId;
	}

	public void setJunctionId(String junctionId) {
		this.junctionId = junctionId;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public String getBookCount() {
		return bookCount;
	}

	public void setBookCount(String bookCount) {
		this.bookCount = bookCount;
	}


	
    
    
}
