package com.mphasis.hrms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mphasis.hrms.entity.Feedback;
import com.mphasis.hrms.repository.FeedbackRepository;

@Component("fs")
public class FeedbackService {
	@Autowired
	private FeedbackRepository FeedRepo;
	public Feedback create(Feedback feedback) 
    {
        return FeedRepo.save(feedback);
    }
   
    public Feedback read(String userId) 
    {
        return FeedRepo.findById(userId).get();
    }
    public Feedback update(Feedback feedback) 
    {
        return FeedRepo.save(feedback);
    }
    public void delete(String userId) 
    {
        FeedRepo.delete(read(userId));
    }
	public List<Feedback> read() {
		return FeedRepo.findAll();
		
	}
    

}
