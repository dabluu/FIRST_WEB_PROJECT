package com.mphasis.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mphasis.hrms.entity.Junction;
import com.mphasis.hrms.entity.Order;

@Repository
public interface JunctionRepository extends JpaRepository<Junction, String> {

}
