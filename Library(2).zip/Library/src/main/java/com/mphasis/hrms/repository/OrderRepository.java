package com.mphasis.hrms.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mphasis.hrms.entity.AccountId;
import com.mphasis.hrms.entity.Order;
@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
	@Transactional
	@Modifying
	@Query("update Order o set o.status=:status where o.orderId=:orderId and o.book.bookId=:bookId ")
	public int updateStatus(@Param("status")String status,@Param("orderId")Integer orderId,@Param("bookId")String bookId);

}
