package com.mphasis.hrms.entity;

import java.io.Serializable;
import java.util.Objects;

public class AccountId implements Serializable {

    private String orderId;
    private Book book;

    public AccountId() {
    }

    

    public AccountId(String orderId, Book book) {
		super();
		this.orderId = orderId;
		this.book = book;
	}



	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AccountId accountId = (AccountId) o;
        return orderId.equals(accountId.orderId) &&
                book.equals(accountId.book);
    }

    @Override
    public int hashCode() {
        return Objects.hash(orderId,book);
    }
}