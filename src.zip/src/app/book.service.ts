import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  url:string="http://localhost:8081/book/";
  constructor(private http:HttpClient) { }

  addBook(book:any){
    return this.http.post(this.url,book);
    //alert("service:add");
  }
  modifyBook(book:any){
    return this.http.put(this.url,book);
    //alert("service:modify");
  }
  deleteBook(bookId:string){
    return this.http.delete(this.url+bookId);
    //alert("service:delete");
  }
  getAllBooks(){
    return this.http.get(this.url); 
    //alert("service:read all");
  }
  findBookById(bookId:string){
    return this.http.get(this.url+bookId);
    //alert("service:read by id");
  }
}
