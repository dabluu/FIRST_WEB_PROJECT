import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent implements OnInit,DoCheck {
  userId:string="";
  role:string="";
  visible:boolean=true;
  value:any;
  constructor(private router:Router) { }
  ngDoCheck(): void {
    var userId=localStorage.getItem("userId");
    var role=localStorage.getItem("role");
  	  if(userId&&role!=null){
		    this.userId=userId;
        this.role=role;
        this.value="logout";
        if(role!="Admin"){
          this.visible=false;
        }
        else{
          this.visible=true;
        }
	    }
      else{
        this.value="login";
      }    
  }

  ngOnInit(): void {

  }

  fnLogout(){
    var userId=localStorage.getItem("userId");
    if(userId!=null){
      this.value="Log Out";
    }
    else{
      this.value="Log In";
    }
    // localStorage.removeItem("userId");
    // localStorage.removeItem("password");
    // localStorage.removeItem("bookList");
    // this.router.navigate([{outlets:{'col3':['login']}}]); 

  }

}
