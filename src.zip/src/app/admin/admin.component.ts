import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  userId:string="";
  role:string="";
  constructor(private router:Router) { }

  ngOnInit(): void {
    var userId=localStorage.getItem("userId");
    var role=localStorage.getItem("role");
  	  if(userId&&role!=null){
		    this.userId=userId;
        this.role=role;
        if(role!="Admin"){
          alert("Only Admin can access to this page.");
          this.router.navigate([{outlets:{'col3':['home']}}]);
        }
	    }
      else
        this.router.navigate([{outlets:{'col3':['login']}}]);
  }

  fnvendor(){
    this.router.navigate([{outlets:{'col3':['vendor']}}]);
  }
  fnorder(){
    this.router.navigate([{outlets:{'col3':['order']}}]);
  }
  fnbook(){
    this.router.navigate([{outlets:{'col3':['book']}}]);
  }
  fnuser(){
    this.router.navigate([{outlets:{'col3':['user']}}]);
  }
  fnjunction(){
    this.router.navigate([{outlets:{'col3':['junction']}}]);
  }

}
