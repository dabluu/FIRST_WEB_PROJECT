import { Junction } from './junction';

describe('Junction', () => {
  it('should create an instance', () => {
    expect(new Junction()).toBeTruthy();
  });
});
