import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {

  url:string="http://localhost:8081/feedback/"
  constructor(private http:HttpClient) { }

  addFeedback(feedback:any){
    return this.http.post(this.url,feedback);
  }
}