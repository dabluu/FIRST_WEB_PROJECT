import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  url:string="http://localhost:8081/user/"
  constructor(private http:HttpClient) { }

  addUser(user:any){
    return this.http.post(this.url,user);
  }
  updateUser(user:any){
    return this.http.put(this.url,user);
  }
  deleteUser(userId:any){
    return this.http.delete(this.url,userId);
  }
  validateLogin(userId:string,password:string){
    return this.http.get(this.url+userId+"/"+password);
  }
  getAllUsers(){
    return this.http.get(this.url); 
    //alert("service:read all");
  }

  generateOtp(email:string)
  {
    return this.http.post(this.url+"otp",email);
  }
}
