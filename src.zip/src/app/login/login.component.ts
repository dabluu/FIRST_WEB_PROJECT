
import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user:User=new User();
  loginForm:any;
  status:string="";
  constructor(private fb:FormBuilder, private us:UserService,private router:Router) {
    this.loginForm=this.fb.group(
      {
        userId:[''],
        password:[''],
        showPassword:[''],
        rememberMe:[true],
        userId1:[''],
        password1:['']
      }
    );
   }

  ngOnInit(): void {
    var rememberMe=this.loginForm.controls.rememberMe.value;
    if(rememberMe)
    {
     	var userId1=localStorage.getItem("userId1");
     	var password1=localStorage.getItem("password1");
  	  if(userId1!=null){
		    this.loginForm.controls.userId.value=userId1;
	    }
	    this.loginForm.controls.password.value=password1;
    }
  }


  fnLogin(){
    var userId1=this.loginForm.controls.userId.value;
    var password1=this.loginForm.controls.password.value;
    var userId=this.loginForm.controls.userId.value;
    var password=this.loginForm.controls.password.value;


    var rememberMe=this.loginForm.controls.rememberMe.value;
    if(rememberMe)
    {
	      localStorage.setItem("userId1",userId1);
	      localStorage.setItem("password1",password1);
    }
    else{
	      localStorage.removeItem("userId1");
	      localStorage.removeItem("password1");
    }

    //alert(userId+":"+password);
    this.us.validateLogin(userId,password).subscribe((data)=>{
      console.log(data);
      //alert(JSON.stringify(data));
      if(data==null)
        this.status="FAILURE";
      else
      {  
        this.status="SUCCESS!!!";
        this.user=<User>data;
        var role=this.user.role;
        localStorage.setItem("userId",userId);
        localStorage.setItem("role",role);
        this.router.navigate([{outlets:{'col3':['home']}}]); 
      
     // alert(this.user.firstName);
    }
    });

  }
}
