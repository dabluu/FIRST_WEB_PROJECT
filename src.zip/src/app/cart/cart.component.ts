import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  bookList:string="";
  bookArray:string[]=[];
  bookForm:any;
  bookId:any;
  bookData:Book[]=[];
  newbookArray:string[]=[];
  bookCount:any;
  book=new Book();
  bookCost:number=0;
  constructor(private bs:BookService,private router:Router) { }

  ngOnInit(): void {
    var bookList=localStorage.getItem("bookList");
    if(bookList!=null){
      this.bookList=bookList;
      this.bookArray=this.bookList.split(',');
      this.bookCount=this.bookArray.length;
      for(let i=0;i<this.bookArray.length;i++){
        this.bookId=this.bookArray[i];
        this.fnselect(this.bookId);

      }
     
    }
    
  }

  fnselect(bookId:string){
    this.bs.findBookById(bookId).subscribe((data)=>{
      console.log(data);
      //this.vendorForm.patchValue(data);
      this.book=<any>data; 
      this.bookCost+=this.book.cost;
      this.bookData.push(<any>data);
      
    });
  }

  fnremove(bookId:string){
    var index = this.bookArray.indexOf(bookId);
    this.newbookArray = (index > -1) ? [
      ...this.bookArray.slice(0, index),
      ...this.bookArray.slice(index + 1)
  ] : this.bookArray;
  this.bookArray=this.newbookArray;
  this.bookList=this.bookArray.toString();
  localStorage.setItem("bookList",this.bookList);
  window.location.reload();
  }

  fnpayment(){
    this.router.navigate([{outlets:{'col3':['payment']}}]);
  }

}
