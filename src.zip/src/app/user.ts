export class User {
    userId:string="";
    firstName:string="";
    lastName:string="";
    password:string="";
    dateOfBirth:Date=new Date();
    email:string="";
    contactNo:number=0;
    role:string="";
}


// private String userId;
// private String firstName;
// private String lastName;
// private String password;
// private Date dateOfBirth;
// private String email;
// private Integer contactNo;
// private String role;