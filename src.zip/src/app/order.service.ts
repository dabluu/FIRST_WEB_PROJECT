import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  url:string="http://localhost:8081/order/";
  constructor(private http:HttpClient) { }
  
  addOrder(order:any){
    return this.http.post(this.url,order);
    //alert("service:add");
  }
  getAllOrders(){
    return this.http.get(this.url); 
    //alert("service:read all");
  }
  updateOrder(order:any){
    return this.http.put(this.url,order);
  }

  findOrderById(orderId:any){
    return this.http.get(this.url+orderId);
    //alert("service:read by id");
  }

  updateStatus(formData:any){
    return this.http.post(this.url+"/us",formData);
  }
  
}
