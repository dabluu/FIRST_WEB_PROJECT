import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  bookForm:any;
  books:any;
  selectedFile:any;
  book=new Book();
  constructor(private fb:FormBuilder,private bs:BookService) {
    this.bookForm=this.fb.group(
      {
        bookId:[''],
        title:[''],
        authorName:[''],
        version:[''],
        publishDate:[''],
        dept:[''],
        language:[''],
        cost:[''],
        pages:[''],
        description:[''],
        photo:[]
      }
    );
   }

   loadBooks(){
    this.bs.getAllBooks().subscribe((data)=>{
      console.log(data);
      this.books=data;
    });
   }

  ngOnInit(): void {
    this.loadBooks();
  }

  

  onFileChanged(event:any){
      this.selectedFile=event.target.files[0];
      console.log(JSON.stringify(this.selectedFile));
  }

  fnAdd(){
    var formData=new FormData();
    formData.append('bookId',this.bookForm.controls.bookId.value);
    formData.append('title',this.bookForm.controls.title.value);
    formData.append('authorName',this.bookForm.controls.authorName.value);
    formData.append('version',this.bookForm.controls.version.value);
    formData.append('publishDate',this.bookForm.controls.publishDate.value);
    formData.append('dept',this.bookForm.controls.dept.value);
    formData.append('language',this.bookForm.controls.language.value);
    formData.append('cost',this.bookForm.controls.cost.value);
    formData.append('pages',this.bookForm.controls.pages.value);
    formData.append('description',this.bookForm.controls.description.value);
    formData.append('photo',this.selectedFile,this.selectedFile.name);

    this.bs.addBook(formData).subscribe((data)=>{
      console.log(data);
      this.loadBooks();
    });
    //alert("addding...."+JSON.stringify(vendor));
  }
  fnUpdate(){
    var formData=new FormData();
    formData.append('bookId',this.bookForm.controls.bookId.value);
    formData.append('title',this.bookForm.controls.title.value);
    formData.append('authorName',this.bookForm.controls.authorName.value);
    formData.append('version',this.bookForm.controls.version.value);
    formData.append('publishDate',this.bookForm.controls.publishDate.value);
    formData.append('dept',this.bookForm.controls.dept.value);
    formData.append('language',this.bookForm.controls.language.value);
    formData.append('cost',this.bookForm.controls.cost.value);
    formData.append('pages',this.bookForm.controls.pages.value);
    formData.append('description',this.bookForm.controls.description.value);
    formData.append('photo',this.selectedFile,this.selectedFile.name);

    this.bs.modifyBook(formData).subscribe((data)=>{
      console.log(data);
      this.loadBooks();
    });
    //alert("updating...");
  }
  fnDelete(){
    var bookId=this.bookForm.controls.bookId.value;
    this.bs.deleteBook(bookId).subscribe((data)=>{
      console.log(data);
      this.loadBooks();
    });
    //alert("deleting...");
  }

  fnFindById(){
    var bookId=this.bookForm.controls.bookId.value;
    this.fnselect(bookId);
  }
  fnselect(bookId:string){
    this.bs.findBookById(bookId).subscribe((data)=>{
      console.log(data);
      this.book=<Book><any>data;  
      var strDt=<string><any>this.book.publishDate;
      strDt=strDt.substring(0,strDt.indexOf("T"));

      this.bookForm.controls.bookId.patchValue(this.book.bookId);
      this.bookForm.controls.title.patchValue(this.book.title);
      this.bookForm.controls.authorName.patchValue(this.book.authorName);
      this.bookForm.controls.version.patchValue(this.book.version);
      this.bookForm.controls.dept.patchValue(this.book.dept);
      this.bookForm.controls.language.patchValue(this.book.language);
      this.bookForm.controls.cost.patchValue(this.book.cost);
      this.bookForm.controls.pages.patchValue(this.book.pages);
      this.bookForm.controls.description.patchValue(this.book.description);
      this.bookForm.controls.publishDate.patchValue(strDt);

    });
  }

  

}
