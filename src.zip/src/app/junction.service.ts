import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class JunctionService {

  url:string="http://localhost:8081/junction/";
  constructor(private http:HttpClient) { }

  addJunction(junction:any){
    return this.http.post(this.url,junction);
    //alert("service:add");
  }
  modifyJunction(junction:any){
    return this.http.put(this.url,junction);
    //alert("service:modify");
  }
  deleteJunction(junctionId:string){
    return this.http.delete(this.url+junctionId);
    //alert("service:delete");
  }
  getAllJunctions(){
    return this.http.get(this.url); 
    //alert("service:read all");
  }
  findJunctionById(junctionId:string){
    return this.http.get(this.url+junctionId);
    //alert("service:read by id");
  }
}
