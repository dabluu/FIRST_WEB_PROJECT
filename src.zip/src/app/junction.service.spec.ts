import { TestBed } from '@angular/core/testing';

import { JunctionService } from './junction.service';

describe('JunctionService', () => {
  let service: JunctionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(JunctionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
