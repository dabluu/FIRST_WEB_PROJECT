import { Component, DoCheck, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Book } from '../book';
import { BookService } from '../book.service';
import { Junction } from '../junction';
import { JunctionService } from '../junction.service';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-junction',
  templateUrl: './junction.component.html',
  styleUrls: ['./junction.component.css']
})
export class JunctionComponent implements OnInit {
  junction=new Junction();
  junctionForm:any;
  junctions:any;
  vendorId:any;
  constructor(private fb:FormBuilder,private js:JunctionService,private vs:VendorService,private bs:BookService) { 
    this.junctionForm=this.fb.group(
      {
        junctionId:[''],
        vendorId:[''],
        bookId:[''],
        bookCount:['']
      }
    );
  }
  loadJunctions(){
    this.js.getAllJunctions().subscribe((data)=>{
      console.log(data);
      this.junctions=data;
    });
   }
  ngOnInit(): void {
    this.loadJunctions();
  }

  fnAdd(){
    var junction=this.junctionForm.value;
    var vendorId=this.junctionForm.controls.vendorId.value;
    var bookId=this.junctionForm.controls.bookId.value;
    var vendor=new Vendor();
    var book=new Book();
    console.log(vendorId);
    this.vs.findVendorById(vendorId).subscribe((data)=>{
      vendor=<Vendor><any>data;
      junction.vendor=vendor;
      //alert("sending data as:" +JSON.stringify(junction))
      //console.log("sending data as:" +JSON.stringify(junction));
    });
    this.bs.findBookById(bookId).subscribe((data)=>{
      book=<Book><any>data;
      junction.book=book;
      alert("sending data as:" +JSON.stringify(junction))
      //console.log("sending data as:" +JSON.stringify(junction));
      this.js.addJunction(junction).subscribe((data)=>{
        console.log(data);
        this.loadJunctions();
      });
    });
    
    //alert("addding...."+JSON.stringify(vendor));
  }
  fnUpdate(){
    var junction=this.junctionForm.value;
    var vendorId=this.junctionForm.controls.vendorId.value;
    var bookId=this.junctionForm.controls.bookId.value;
    var vendor=new Vendor();
    var book=new Book();
    console.log(vendorId);
    this.vs.findVendorById(vendorId).subscribe((data)=>{
      vendor=<Vendor><any>data;
      junction.vendor=vendor;
      //alert("sending data as:" +JSON.stringify(junction))
      //console.log("sending data as:" +JSON.stringify(junction));
    });
    this.bs.findBookById(bookId).subscribe((data)=>{
      book=<Book><any>data;
      junction.book=book;
      alert("sending data as:" +JSON.stringify(junction))
      //console.log("sending data as:" +JSON.stringify(junction));
      this.js.modifyJunction(junction).subscribe((data)=>{
        console.log(data);
        this.loadJunctions();
      });
    });
    
    //alert("updating...");
  }
  fnDelete(){
    var junctionId=this.junctionForm.controls.junctionId.value;
    this.js.deleteJunction(junctionId).subscribe((data)=>{
      console.log(data);
      this.loadJunctions();
    });
    //alert("deleting...");
  }

  fnFindById(){
    var junctionId=this.junctionForm.controls.junctionId.value;
    this.fnselect(junctionId);
  }
  fnselect(junctionId:string){
    this.js.findJunctionById(junctionId).subscribe((data)=>{
      console.log(data);
      this.junction=<any>data;      
      this.junctionForm.patchValue(data);
      this.junctionForm.controls.vendorId.patchValue(this.junction.vendor.vendorId);
      this.junctionForm.controls.bookId.patchValue(this.junction.book.bookId);
      // this.junctionForm.controls.vendorId.value=this.junction.vendor.vendorId;
      //console.log('patched vendor id:'+this.junctionForm.controls.vendorId.value);
      
    });
  }

}
