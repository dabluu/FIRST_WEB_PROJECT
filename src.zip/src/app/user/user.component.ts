import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userForm:any;
  users:any;
  constructor(private fb:FormBuilder,private us:UserService) {
    this.userForm=this.fb.group(
      {
        userId:[''],
        firstName:[''],
        lastName:[''],
        password:[''],
        dateOfBirth:[''],
        email:[''],
        contactNo:[''],
        role:['']
      }
    );
   }
   loadUsers(){
    this.us.getAllUsers().subscribe((data)=>{
      console.log(data);
      this.users=data;
    });
   }

  ngOnInit(): void {
    this.loadUsers();
  }

}
