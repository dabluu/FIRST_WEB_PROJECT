export class Vendor {
    vendorId:string="";
    vendorName:string="";
    contactNo:string="";
    email:string="";
}
