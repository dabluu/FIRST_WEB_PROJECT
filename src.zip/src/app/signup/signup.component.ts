import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm:FormGroup;
  userRole:string[]=["Customer","Admin"];
  submitted=false;
  dateOfBirth:any;
  dobMessage: any;
  status:any;
  gotp:any;
  otpError:any;
  loading:boolean=false;
  constructor(private fb:FormBuilder,private us:UserService,private router:Router) {
    this.signupForm=this.fb.group(
      {
         
        userId:[''],
        firstName:[''],
        lastName:[''],
        password: ['', Validators.compose([Validators.required, this.patternValidator()])],
        showPassword:[''],
        dateOfBirth:[''],
        email: ['',Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")],
        contactNo: ['', [Validators.required, Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$")]],
        role:[''],
        enteredOtp:[''],
        generatedOtp:[''],
        cPassword: ['', [Validators.required]]
    },
      {
        validator: this.MatchPassword('password', 'cPassword'),
      }
      
    );
  }

  ngOnInit(): void {
  }

  get signupFormControl() {
    return this.signupForm.controls;
  }
  
  fnAdd(){
    this.loading=true;
    var eotp=this.signupForm.controls.enteredOtp.value;
    //alert('comparing '+eotp+' with '+this.gotp);
   // alert('adding...');
   if(eotp!=this.gotp)
   {
    this.otpError="Entered otp is invalid";
     return;
   }
    var formData=new FormData();
    formData.append('userId',this.signupForm.controls.userId.value);
    formData.append('firstName',this.signupForm.controls.firstName.value);
    formData.append('lastName',this.signupForm.controls.lastName.value);
    formData.append('password',this.signupForm.controls.password.value);
    formData.append('dateOfBirth',this.signupForm.controls.dateOfBirth.value);
    formData.append('email',this.signupForm.controls.email.value);
    formData.append('contactNo',this.signupForm.controls.contactNo.value);
    formData.append('role',this.signupForm.controls.role.value);


    this.us.addUser(formData).subscribe((data)=>{
      console.log(data);
      this.router.navigate([{outlets:{'col3':['login']}}]);
      setTimeout(()=>{

      }, 10000);
      this.loading=false;
    });
  }


  onSubmit(event:any) {
    if (this.signupForm.invalid)
    {      return;
    }
  
      else
     this.fnAdd();
 }

 

 patternValidator(): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } => {
    if (!control.value) {
      return null as any;
    }
    const regex = new RegExp('^(?=.?[A-Z])(?=.?[a-z])(?=.*?[0-9]).{8,}$');
    const valid = regex.test(control.value);
    return valid ?  null as any : { invalidPassword: true };
  };
}



MatchPassword(password: string, cPassword: string) {
  return (formGroup: FormGroup) => {
    const passwordControl = formGroup.controls[password];
    const confirmPasswordControl = formGroup.controls[cPassword];

    if (!passwordControl || !confirmPasswordControl) {
      return null as any;
    }

    if (confirmPasswordControl.errors && !confirmPasswordControl.errors.passwordMismatch) {
      return null as any;
    }

    if (passwordControl.value !== confirmPasswordControl.value) {
      confirmPasswordControl.setErrors({ passwordMismatch: true });
    } else {
      confirmPasswordControl.setErrors(null);
    }
  }
}
fnCheckDate() {
  var dob = new Date(this.dateOfBirth);
  var today = new Date();
  if (dob > today) {
    this.status = "failure";
    this.dobMessage = "Date of Birth cannot be future date";
  } 
  else {
    this.dobMessage = "";
  }
}  

fnGenerateOtp()
  {
    //under construction
    var email=this.signupForm.controls.email.value;
    console.log(email);
    this.us.generateOtp(email).subscribe((data)=>{
      console.log(data);
      this.gotp=data;      
    });
    // this.signupForm.controls.generatedOtp.value=this.gotp;
  }

}
