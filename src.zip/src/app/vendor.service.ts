import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VendorService {

  url:string="http://localhost:8081/vendor/";
  constructor(private http:HttpClient) { }

  addVendor(vendor:any){
    return this.http.post(this.url,vendor);
    //alert("service:add");
  }
  modifyVendor(vendor:any){
    return this.http.put(this.url,vendor);
    //alert("service:modify");
  }
  deleteVendor(vendorId:string){
    return this.http.delete(this.url+vendorId);
    //alert("service:delete");
  }
  getAllVendors(){
    return this.http.get(this.url); 
    //alert("service:read all");
  }
  findVendorById(vendorId:string){
    console.log("sevice" +vendorId);
    return this.http.get(this.url+vendorId);
    //alert("service:read by id");
  }
}
