import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminComponent } from './admin/admin.component';
import { BookComponent } from './book/book.component';
import { CartComponent } from './cart/cart.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { HomeComponent } from './home/home.component';
import { JunctionComponent } from './junction/junction.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { OrderComponent } from './order/order.component';
import { PaymentComponent } from './payment/payment.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';
import { VendorComponent } from './vendor/vendor.component';

const routes: Routes = [{path:'signup',component:SignupComponent,outlet:'col3'},
{path:'login',component:LoginComponent,outlet:'col3'},
{path:'vendor',component:VendorComponent,outlet:'col3'},
{path:'order',component:OrderComponent,outlet:'col3'},
{path:'home',component:HomeComponent,outlet:'col3'},
{path:'admin',component:AdminComponent,outlet:'col3'},
{path:'book',component:BookComponent,outlet:'col3'},
{path:'user',component:UserComponent,outlet:'col3'},
{path:'junction',component:JunctionComponent,outlet:'col3'},
{path:'cart',component:CartComponent,outlet:'col3'},
{path:'payment',component:PaymentComponent,outlet:'col3'},
{ path: '', component: HomeComponent,outlet:'col3'},
{path:'logout',component:LogoutComponent,outlet:'col3'},
{path:'feedback',component:FeedbackComponent,outlet:'col3'},
{path:'about-us',component:AboutUsComponent,outlet:'col3'},
{path:'contact-us',component:ContactUsComponent,outlet:'col3'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
