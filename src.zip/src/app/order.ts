import { Book } from "./book";
import { User } from "./user";

export class Order {
    orderId:number=0;
    book:Book=new Book();
    //userId:String="";
    user:User=new User();
    status:string="";
    orderDate:Date=new Date();
}
