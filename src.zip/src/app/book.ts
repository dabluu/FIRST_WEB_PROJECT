export class Book {
    bookId:string="";
    title:string="";
    authorName:string="";
    version:string="";
    publishDate:Date=new Date();
    dept:string="";
    language:string="";
    cost:number=0;
    pages:string="";
    description:string="";
    photo:File|any;
}
