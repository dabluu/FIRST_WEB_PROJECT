import { Book } from "./book";
import { Vendor } from "./vendor";

export class Junction {
    junctionId:string="";
    vendor:Vendor=new Vendor();
    book:Book=new Book();
    bookCount:number=0;
}
