import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  userId:any;
  role:any;
  orderForm:any;
  bookList:any;
  bookArray:string[]=[];
  status:string="Pending";
  orderDate:Date=new Date();
  order=new Order();
  bookId="";
  paymentForm:any;
  addr:any;
  constructor(private router:Router,private os:OrderService,private fb:FormBuilder) { 
    this.paymentForm=this.fb.group(
      {
        address:['',[Validators.required]],
        city:['',[Validators.required]],
        pincode:['', [Validators.required, Validators.pattern("^[0-9]{6}$")]]
      });

  }

  ngOnInit(): void {
    var userId=localStorage.getItem("userId");
    var role=localStorage.getItem("role");
    var bookList=localStorage.getItem("bookList");
  	  if(userId&&role&&bookList!=null){
		    this.userId=userId;
        this.role=role;
        this.bookList=bookList;
	    }
      
      else
        this.router.navigate([{outlets:{'col3':['login']}}]); 
    
  }

  fnConfirmOrder(){
    console.log();
    var address=this.paymentForm.controls.address.value;
    var city=this.paymentForm.controls.city.value;
    var pincode=this.paymentForm.controls.pincode.value;

    this.addr=(address+","+city+"-"+pincode);
    console.log(typeof(this.bookList))
    console.log(this.bookList);
    this.bookArray=this.bookList.split(',');
      for(let i=0;i<this.bookArray.length;i++){
        this.bookId=this.bookArray[i];
        console.log(this.bookId);
        this.fnAdd(this.bookId);
      }
      
      Swal.fire({
      
        icon: 'success',
        title: 'Successfully your order has been placed',
        showConfirmButton: false,
        timer: 2500
      })
      
  }

  fnAdd(bookId:any){
    var formData=new FormData();
    //formData.append("orderId",this.orderId);
    formData.append("bookId",bookId);
    formData.append("userId",this.userId);
    formData.append("status",this.status);
    formData.append("address",this.addr);

    //n.substring(0,n.indexOf("T"))
    var dt=this.orderDate.toISOString();
    var orderDate=dt.substring(0,dt.indexOf("T"));
    formData.append("orderDate",orderDate);

    this.os.addOrder(formData).subscribe((data)=>{
      console.log(data);
    });
    //alert("addding...."+JSON.stringify(vendor));
  }

}
