import { Component, DoCheck, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit,DoCheck {

  constructor(private router:Router) { }
  ngDoCheck(): void {
    localStorage.removeItem("userId");
    localStorage.removeItem("password");
    localStorage.removeItem("bookList");
    this.router.navigate([{outlets:{'col3':['login']}}]); 
  }

  ngOnInit(): void {
  }

}
