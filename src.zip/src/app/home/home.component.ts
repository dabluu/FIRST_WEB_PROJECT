import { DeclarationListEmitMode } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../book';
import { BookService } from '../book.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userId:string="";
  role:string="";
  books:any;
  bookForm:any;
  bookList:string[]=[];
  isCollapsed:boolean=true;
  // status:string="Further Details";
  status:string[]=[];
  bookNumber:string="";
  collapse:boolean[]=[];
  book=new Book();
  //let bookList: Array = [userId,role]
  constructor(private router:Router,private bs:BookService) { }

  loadBooks(){
    this.bs.getAllBooks().subscribe((data)=>{
      console.log(data);
      this.books=data;
      for(var b  of this.books)
      {
        this.collapse.push(true);
        this.status.push('More Details');
      }
    });
   }

  ngOnInit(): void {
    var userId=localStorage.getItem("userId");
    var role=localStorage.getItem("role");
  	  if(userId&&role!=null){
		    this.userId=userId;
        this.role=role;
	    }
      // else
      //   this.router.navigate([{outlets:{'col3':['login']}}]); 
    this.loadBooks();
  }

  fnselect(bookId:string){
    this.bs.findBookById(bookId).subscribe((data)=>{
      console.log(data);
      this.book=<any>data; 
      alert(this.book.title+" book has been added to the cart");
    });
    this.bookList.push(bookId)
    localStorage.setItem("bookList",this.bookList.toString());
    console.log("fnselect method displaying bookList.toString() as :"+this.bookList.toString());
  }
  
  toggleCollapse(i:number){
    if(this.collapse[i])
    {
      this.status[i]="Lesser Details";      
    }
    else{
      this.status[i]="More Details";      
    }
    this.collapse[i]=!this.collapse[i];
  }

}
