import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { SignupComponent } from './signup/signup.component';
import { HomeComponent } from './home/home.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { VendorComponent } from './vendor/vendor.component';
import { OrderComponent } from './order/order.component';
import { AdminComponent } from './admin/admin.component';
import { BookComponent } from './book/book.component';
import { UserComponent } from './user/user.component';
import { JunctionComponent } from './junction/junction.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { LogoutComponent } from './logout/logout.component';
import { FeedbackComponent } from './feedback/feedback.component';
import Swal from 'sweetalert2';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';

@NgModule({
  declarations: [
    AppComponent,
    SignupComponent,
    MenuComponent,
    HomeComponent,
    LoginComponent,
    VendorComponent,
    OrderComponent,
    AdminComponent,
    BookComponent,
    UserComponent,
    JunctionComponent,
    CartComponent,
    PaymentComponent,
    LogoutComponent,
    FeedbackComponent,
    AboutUsComponent,
    ContactUsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
